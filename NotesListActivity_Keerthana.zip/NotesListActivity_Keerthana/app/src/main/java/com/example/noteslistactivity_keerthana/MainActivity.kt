package com.example.noteslistactivity_keerthana

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val viewNotesButton: Button = findViewById(R.id.viewNotesButton)
        viewNotesButton.setOnClickListener {
            val intent = Intent(this, NotesListActivity::class.java)
            startActivity(intent)
        }
    }
}
