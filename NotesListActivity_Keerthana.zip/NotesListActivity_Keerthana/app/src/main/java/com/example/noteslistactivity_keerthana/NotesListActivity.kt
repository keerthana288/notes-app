package com.example.noteslistactivity_keerthana

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class NotesListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes_list)
    }
}
